# AEON — Adverse Event Orchestration Nexus
## Enterprise Monorepo

Scaled from the validated `aeon_vertical_slice.py` MVP per `AEON_Technical_Blueprint.md`.

## What's real vs. what's scaffolding — read this first

| Component | Status |
|---|---|
| Backend structure, models, endpoints, auth, Celery worker | Real, working code. Not yet run end-to-end here (no network access in this sandbox) — syntax-checked only, you should be the first to run it. |
| FDA FAERS cartridge | Reference-quality mapping based on the public E2B(R3) structure. Still not verified against FDA's actual ESG submission requirements. |
| Other 9 cartridges (EMA, MHRA, TGA, PMDA, Health Canada, ANVISA, CDSCO, NMPA, WHO) | **Structural drafts only.** Seeded `is_active=False`. Do not treat as functional — see `backend/app/cartridges/README.md`. |
| Alembic migration / TimescaleDB | Real hypertable setup, with one genuine tradeoff flagged inline (composite PK required on `adr_reports`). |
| Frontend (dashboard, snap-submit, settings) | Functional React/Next.js structure. Not build-tested (no Node/network access here). |
| Terraform | Generic, correct-shape AWS scaffolding. Needs real ACM cert ARN, secrets-manager wiring, and account-specific review before `apply`. |
| Tests | Real, deterministic unit tests (no live Celery/Redis/Postgres required to run `test_nlp.py` / `test_mapper.py` / `test_submission.py`). |

## Quickstart

```bash
./deploy.sh
```

Requires Docker, Python 3, Node.js. Spins up Postgres+TimescaleDB, Redis, backend, Celery worker, frontend, and Nginx; runs migrations; seeds cartridges (FDA active, others inactive) and one demo admin user.

## Before this touches real patient data or real regulatory submissions

1. Get a pharmacovigilance/regulatory-compliance consultant to verify every cartridge beyond FDA — several of these authorities (EudraVigilance, PMDA, NMPA) may not offer an open third-party submission path at all.
2. Replace the MVP-grade regex/lexicon NLP extractor with an actual fine-tuned biomedical NER model (BioBERT/PubMedBERT) trained and evaluated on real ADR narratives — the current extractor only recognizes a small hardcoded antibiotic list and 3 reaction keywords.
3. Run this whole stack through a real security review before handling PHI — JWT/RBAC scaffolding here is a starting point, not a compliance sign-off.
